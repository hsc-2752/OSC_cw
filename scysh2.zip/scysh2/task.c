#include <stdio.h>
#include <stdlib.h>
#include <sys/time.h>
#include <semaphore.h>
#include <pthread.h>
#include "coursework.h"


pthread_mutex_t lock;
sem_t empty;
sem_t full;
int response_time[NUMBER_OF_PROCESSES];
int turn_around_time[NUMBER_OF_PROCESSES];
struct Buffer * buffer; 
int produced_num = 0;
int consumed_num = 0;
int consumed_process_num = 0;
int num_of_slices = 0;

struct Buffer { 
    struct process *head, * tail; 
}; 
  

struct Buffer* newBuffer() 
{ 
    struct Buffer* b = (struct Buffer*)malloc(sizeof(struct Buffer)); 
    b -> head = NULL;
    b -> tail = NULL; 
    return b; 
} 
  

void add(struct Buffer* b, struct process* p) 
{ 
    if(b -> tail == NULL){
        b->head = b->tail = p;
        return;
    }
    if (b -> head == NULL) { 
        b -> head = p;
        b -> tail = p; 
    } 
    else{
        b -> tail -> oNext = p; 
        b -> tail = p; 
    }
} 
  
//since in the producer-consuemr problem we do not allow removal from empty buffer,
//we do not consider empty linked list here(need to free)
struct process* delete(struct Buffer* b) 
{ 
    if (b->head == NULL){
        return NULL;
    }
    struct process* temp = b -> head; 
    //free(b -> head);
    b-> head = b -> head -> oNext; 
    if(b->tail == temp){
        b->tail = NULL;
    }
    return temp; 
} 



void* produce(void* arg){

	while (produced_num < NUMBER_OF_PROCESSES){
        sem_wait(&empty);

        struct process* p = generateProcess();

        num_of_slices = num_of_slices + (p->iBurstTime+TIME_SLICE-1)/TIME_SLICE;

        pthread_mutex_lock(&lock);
        produced_num++;
        add(buffer,p);
        pthread_mutex_unlock(&lock);
        
        sem_post(&full);

	}
    pthread_exit(NULL);
}

void* consume(void* arg){
	int * consumer_index = (int*)(arg);
	struct timeval t_start,t_end;
	int previous_burst_time = 0;
    int active = 0;
    int exit = 0;

    while(consumed_num<=num_of_slices){
        if(NUMBER_OF_PROCESSES-consumed_process_num<=NUMBER_OF_CONSUMERS){
            exit = 1;
        }
        sem_wait(&full); 

        pthread_mutex_lock(&lock);

        struct process* p = delete(buffer);
        consumed_num++;
        if(consumed_num == num_of_slices){
            exit = 1;
        }
        pthread_mutex_unlock(&lock);
         
        int isNew = 0;
        previous_burst_time = p->iBurstTime;
        if(p->iState == NEW){
        	isNew = 1;
        }
       
    
        simulateRoundRobinProcess(p,&t_start,&t_end);

        //pthread_mutex_lock(&lock); 
        if(isNew){
        	response_time[p->iProcessId] = getDifferenceInMilliSeconds(p->oTimeCreated,t_start);
        	printf("Consumer ID = %d, Process ID = %d, Previous Burst Time = %d, New Burst Time = %d, Response Time = %d\n",
                                 *consumer_index,p->iProcessId,previous_burst_time,p->iBurstTime,getDifferenceInMilliSeconds(p->oTimeCreated,t_start));
        }
        
        if(p->iState == READY){  
            pthread_mutex_lock(&lock); 
            add(buffer,p);
            pthread_mutex_unlock(&lock);
            sem_post(&full);
            if(!isNew){
                    printf("Consumer ID = %d, Process ID = %d, Previous Burst Time = %d, New Burst Time = %d\n",
         	                  *consumer_index,p->iProcessId,previous_burst_time,p->iBurstTime);
            }       

        }
        
        if(p->iState == FINISHED){
            pthread_mutex_lock(&lock); 
            consumed_process_num++;
            pthread_mutex_unlock(&lock);
            //if(!exit){
            sem_post(&empty);
            //}
        	turn_around_time[p->iProcessId] = getDifferenceInMilliSeconds(p->oTimeCreated,t_end);
            printf("Consumer ID = %d, Process ID = %d, Previous Burst Time = %d, New Burst Time = %d, Turn Around Time = %d\n",
                                 *consumer_index,p->iProcessId,previous_burst_time,p->iBurstTime,getDifferenceInMilliSeconds(p->oTimeCreated,t_end));
            // printf("%d\n",exit);

            free(p);
            if(exit==1){
                break;

            }

        }
        //pthread_mutex_unlock(&lock);
	}

  pthread_exit(NULL);

}
 
int main(void){
	int i,j,k;

    pthread_mutex_init(&lock, NULL);

    for(j = 0; j < NUMBER_OF_PROCESSES; j++){
    	response_time[j] = 0;
        turn_around_time[j] = 0;
    }


    sem_init(&empty, 0, BUFFER_SIZE);
    sem_init(&full, 0, 0);

    pthread_t producer_id;
    pthread_create(&producer_id, NULL, produce, NULL);

    pthread_t consumer_id[NUMBER_OF_CONSUMERS];
    int consumer_index[NUMBER_OF_CONSUMERS];

    buffer = newBuffer();

    for(i = 0; i < NUMBER_OF_CONSUMERS; i++){
    	consumer_index[i] = i;
    	pthread_create(&consumer_id[i], NULL, consume, (consumer_index+i));
    }


    pthread_join(producer_id, NULL);

    for(i = 0; i < NUMBER_OF_CONSUMERS; i++){
    	pthread_join(consumer_id[i], NULL);
    }


    //calculate average response time and turn around time

    int sum_response_time = 0;
    int sum_turn_around_time = 0;

    for(k = 0; k < NUMBER_OF_PROCESSES;k++){
    	sum_response_time += response_time[k];
    	sum_turn_around_time += turn_around_time[k];
    }

    printf("Average response time = %lf\n",(double)(sum_response_time)/NUMBER_OF_PROCESSES);
    printf("Average turn around time = %lf\n",(double)(sum_turn_around_time)/NUMBER_OF_PROCESSES);

    pthread_mutex_destroy(&lock);
    sem_destroy(&empty);
    sem_destroy(&full);
}



